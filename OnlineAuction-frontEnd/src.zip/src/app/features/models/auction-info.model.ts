export class AuctionInfo {
    auctionId!: number;
    productId!: number;
    auctionStartTime!: Date;
    auctionEndTime!: Date;
    auctionStatus!: string;
  }
  