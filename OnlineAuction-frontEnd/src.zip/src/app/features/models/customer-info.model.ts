export class CustomerInfo {
    customerId!: number;
    firstName!: string;
    lastName!: string;
    email!: string;
    password!: string;
    contactNumber!: string;
    invoiceInfoList!: any[];
    bidInfoList!: any[];
    paymentInfoList!: any[]; 
    shippingInfoList!: any[];
  }
  