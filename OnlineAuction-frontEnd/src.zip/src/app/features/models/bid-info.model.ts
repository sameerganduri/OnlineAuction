export class BidInfo {
    bidId?: number;
    productId?: number;
    customerId?: number;
    bidAmount?: number;
    bidTime?: string;
    status?: string;
  }
  