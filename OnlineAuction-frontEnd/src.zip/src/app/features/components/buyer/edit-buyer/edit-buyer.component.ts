import { Component } from '@angular/core';

@Component({
  selector: 'app-edit-buyer',
  templateUrl: './edit-buyer.component.html',
  styleUrls: ['./edit-buyer.component.scss']
})
export class EditBuyerComponent {

}
