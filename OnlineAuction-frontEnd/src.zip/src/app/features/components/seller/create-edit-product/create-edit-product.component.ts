import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { CategoryInfo } from 'src/app/features/models/category-info.model';
import { ProductInfo } from 'src/app/features/models/product-info.model';
import { SellerService } from 'src/app/features/services/seller.service';
@Component({
  selector: 'app-create-edit-product',
  templateUrl: './create-edit-product.component.html',
  styleUrls: ['./create-edit-product.component.scss']
})

export class CreateEditProductComponent implements OnInit {
  productForm!: FormGroup;
    categoriesList: CategoryInfo[]=[];
    productId!:number;
    sellerEmail!:String;
    user_data:any;
    products!: ProductInfo[];
    product?:ProductInfo;

  constructor(private sellerService: SellerService,private fb:FormBuilder,private activatedRoute:ActivatedRoute) { }

  ngOnInit(): void {
   this.productId= this.activatedRoute.snapshot.queryParams['productId']
   this.user_data = localStorage.getItem('user_data');
   this.sellerEmail = this.activatedRoute.snapshot.queryParams['email']
   console.log(this.sellerEmail)
   
   




   if(this.productId!=0){
   console.log( 'current product',this.product)
   }

    this.createProductValidation();
    this.getCategories();
    this.getSeller();
  }

  getCategories(): void {
     this.sellerService.getAllCategorys()
       .subscribe(

        {
          next:(resp:any)=>{
            this.categoriesList = resp.data
          console.log(this.categoriesList)
          }
        }
      
       )
  
      
}


getSeller(): void {
  this.sellerService.getSellerByEmailId(this.sellerEmail).subscribe(
{ next:(resp:any)=>{

  let sellerDetails = resp
  let productDetails =sellerDetails.products
  let productId = this.productId
  console.log(productDetails)
  productDetails.forEach(
    function(valueById:any){
if(productId === valueById['productId']){
productDetails = valueById;

  }
  
})

console.log(productDetails)
this.productForm.patchValue(productDetails)


} });
  };

createProductValidation(){

  this.productForm=this.fb.group(
    {productId:[],
    productName:[],
    description:[],
    startingPrice:[],
    imageUrl:[],
    categoryId:[],
    categories:[],
    
    }
  )
  

}

  onSubmit(): void {
    this.productForm.value['productId'] = 0
    
    this.sellerService.createOrUpdateProduct(this.productForm.value).subscribe(response => {
      console.log(response);
    });
  }
}
