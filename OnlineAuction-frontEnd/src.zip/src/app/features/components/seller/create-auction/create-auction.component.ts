import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FormControl, FormBuilder } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { CategoryInfo } from 'src/app/features/models/category-info.model';
import { ProductInfo } from 'src/app/features/models/product-info.model';
import { SellerService } from 'src/app/features/services/seller.service';

@Component({
  selector: 'app-create-auction',
  templateUrl: './create-auction.component.html',
  styleUrls: ['./create-auction.component.scss']
})
export class CreateAuctionComponent implements OnInit {

auctionForm!:FormGroup;
auctionId!:number;
productId!:number;


constructor(private sellerService:SellerService,private fb:FormBuilder,private activatedRoute:ActivatedRoute){


}


  ngOnInit(): void {
    this.productId= this.activatedRoute.snapshot.queryParams['productId']
    
    
  }

  createAuctionValidation(){

    this.auctionForm=this.fb.group(
      {auctionId:[],
      productId:[],
      auctionEndTime:[],
      auctionStatus:[],
        
      }
    )
    
  
  }


  onSubmit(): void {
    this.auctionForm.value['productId'] = 0
    
    this.sellerService.createOrUpdateProduct(this.auctionForm.value).subscribe(response => {
      console.log(response);
    });
  }

}



