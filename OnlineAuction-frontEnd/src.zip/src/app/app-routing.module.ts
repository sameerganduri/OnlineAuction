import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { BuyerComponent } from './features/components/buyer/buyer.component';
import { HomeComponent } from './general/home/home/home.component';
import { HeaderComponentComponent } from './general/header/header-component/header-component.component';
import { BuyerGuard } from './shared/guards/buyer.guard';
import { SellerComponent } from './features/components/seller/seller.component';
import { CreateEditProductComponent } from './features/components/seller/create-edit-product/create-edit-product.component';
//import { PaymentComponent } from './features/components/payment/payment.component';
import { CreateAuctionComponent } from './features/components/seller/create-auction/create-auction.component';
import { AdminComponent } from './features/components/admin/admin.component';
const routes: Routes = [
  {path:'login',component:LoginComponent},
  {path: ''  ,component:LoginComponent },
  {path:"Buyer",component:BuyerComponent,
 
 
  
  //canActivate:[BuyerGuard],
},
  {path :'', component:LoginComponent},
 { path:'home',component:HomeComponent,
  },

  {
path:'admin',component:HomeComponent,children:[
{ 
  path:'',
  component:AdminComponent
}
]

  },
{
  path:"CreateOrEditProduct/:id",component:CreateEditProductComponent
}
,  {
    path:'header',component:HeaderComponentComponent
      }
,
 {
  path:"Seller",component:HomeComponent,
  children:[
    { path:'',
      component:SellerComponent
    }
  ]


},


 {path:"CreateOrEditProduct",component:CreateEditProductComponent},
// {
//   path:"Payment",component:PaymentComponent
// },
{path:"CreateAuction",component:CreateAuctionComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
