import { Component, Input, OnInit } from '@angular/core';
import { IconProp } from '@fortawesome/fontawesome-svg-core';
import { faIcicles } from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'app-sidenav-component',
  templateUrl: './sidenav-component.component.html',
  styleUrls: ['./sidenav-component.component.scss']
})
export class SidenavComponentComponent implements OnInit{
  @Input() sideNavStatus: boolean = false;

  sideNavList!:Array<any>;

  adminNavList = [
    {name: "kka",icon:faIcicles,_route:"/header"},
    
  ];

  sellerNavList = [
    // Add navigation items for the seller role
  ];

  buyerNavList = [
    // Add navigation items for the buyer role
  ];

ngOnInit(){
  this.sideNavList=this.adminNavList
// this.dataValues = localStorage.
}



}
